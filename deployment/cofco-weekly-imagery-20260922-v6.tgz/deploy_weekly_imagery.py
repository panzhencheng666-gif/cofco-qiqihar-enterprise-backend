"""Guarded weekly-imagery production deployment with an automatic rollback."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time
import urllib.request
import zipfile


RELEASE = "cofco-weekly-imagery-20260922-v6"
ARCHIVE = Path("/tmp") / f"{RELEASE}.tgz"
CHECKPOINT = Path("/var/lib/cofco/checkpoints") / RELEASE
LIVE = Path("/var/lib/cofco/releases/cofco-map-performance-20260912")
JAR = LIVE / "application.jar"
FRONTEND = LIVE / "frontend"
BACKEND_SERVICE = "container-cofco-cloud-oidc-backend-20260910.service"
BACKEND_CONTAINER = "cofco-cloud-oidc-backend-20260910"
FRONTEND_CONTAINER = "cofco-candidate-frontend-20260910"
IMAGERY_ROOT = Path("/var/lib/cofco/imagery")
EXPECTED_JAR = "94eeea06d6775850e51549da8d89e6e24001ae1fd004733a99ab8406b0cd4584"
EXPECTED_FRONTEND = "a23c9d5a1aab4d0a3477604f190f61f287fb8af4b516bcec4812c9fda68d843b"
EXPECTED_CANDIDATE_FRONTEND = "49d78d12382a95bd143d14bfc9edfa332fb2e7035a3415bfb9317486442562c7"


def run(*arguments: str, **kwargs):
    return subprocess.run(arguments, check=True, text=True, **kwargs)


def file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def health() -> None:
    for _ in range(75):
        try:
            with urllib.request.urlopen("http://127.0.0.1:19091/actuator/health", timeout=2) as response:
                if json.loads(response.read())["status"] == "UP":
                    return
        except Exception:
            pass
        time.sleep(1)
    raise RuntimeError("BACKEND_NOT_READY")


def extract(candidate: Path) -> None:
    candidate.mkdir(parents=True)
    with tarfile.open(ARCHIVE) as source:
        for member in source.getmembers():
            path = Path(member.name)
            if path.is_absolute() or ".." in path.parts or not (member.isfile() or member.isdir()):
                raise RuntimeError("UNSAFE_ARCHIVE")
        source.extractall(candidate)


def patched_jar(candidate: Path, destination: Path) -> int:
    replacement_root = candidate / "backend"
    replacements = {
        path.relative_to(replacement_root).as_posix(): path.read_bytes()
        for path in replacement_root.rglob("*.class")
        if not path.name.startswith("._")
    }
    if not replacements:
        raise RuntimeError("NO_BACKEND_CLASSES")
    with zipfile.ZipFile(JAR) as source, zipfile.ZipFile(destination, "w") as target:
        target.comment = source.comment
        existing = set(source.namelist())
        for item in source.infolist():
            target.writestr(item, replacements.get(item.filename, source.read(item.filename)))
        for name in sorted(set(replacements) - existing):
            target.writestr(name, replacements[name], compress_type=zipfile.ZIP_DEFLATED)
    with zipfile.ZipFile(destination) as built:
        for name, data in replacements.items():
            if built.read(name) != data:
                raise RuntimeError(f"CLASS_PATCH_MISMATCH:{name}")
    return len(replacements)


def generated_backend_unit(root: Path) -> tuple[Path, Path]:
    generated = root / "generated"
    generated.mkdir(exist_ok=True)
    run(
        "podman",
        "generate",
        "systemd",
        "--new",
        "--name",
        "--files",
        BACKEND_CONTAINER,
        cwd=generated,
        stdout=subprocess.DEVNULL,
    )
    units = list(generated.glob("*.service"))
    if len(units) != 1:
        raise RuntimeError("BACKEND_UNIT_GENERATION_FAILED")
    base = root / "container-backend-base.service"
    shutil.copy2(units[0], base)
    text = base.read_text()
    marker = "ExecStart=/usr/bin/podman run \\\n"
    if marker not in text:
        raise RuntimeError("BACKEND_EXEC_START_NOT_FOUND_IN_UNIT")
    flags = (
        "--env=QIQIHAR_MAP_IMAGERY_RELEASE_ROOT=/var/lib/cofco/imagery \\\n"
        "\t--volume=/var/lib/cofco/imagery:/var/lib/cofco/imagery:ro \\\n"
        "\t"
    )
    configured = root / BACKEND_SERVICE
    configured.write_text(text.replace(marker, marker + "\t" + flags, 1))
    os.chmod(base, 0o600)
    os.chmod(configured, 0o600)
    return base, configured


def install_worker(candidate: Path) -> None:
    env_file = CHECKPOINT / "weekly-imagery.env"
    shutil.copy2(candidate / "weekly-imagery.env", env_file)
    os.chmod(env_file, 0o600)
    run(
        "bash",
        str(candidate / "worker/scripts/install-weekly-imagery-worker.sh"),
        "--env-file",
        str(env_file),
    )


def restore_container(base_unit: Path) -> None:
    shutil.copy2(base_unit, Path("/etc/systemd/system") / BACKEND_SERVICE)
    os.chmod(Path("/etc/systemd/system") / BACKEND_SERVICE, 0o600)
    run("systemctl", "daemon-reload")
    run("systemctl", "start", BACKEND_SERVICE)
    health()


def main() -> None:
    if len(sys.argv) != 3 or sys.argv[1] not in {"--check", "--apply"}:
        raise SystemExit("usage: deploy_weekly_imagery.py --check|--apply ARCHIVE_SHA256")
    if file_sha(ARCHIVE) != sys.argv[2]:
        raise RuntimeError("ARCHIVE_HASH_MISMATCH")
    CHECKPOINT.mkdir(parents=True, exist_ok=True)
    os.chmod(CHECKPOINT, 0o700)
    released = CHECKPOINT / "released.json"
    if released.exists():
        print("ALREADY_RELEASED", released.read_text())
        return
    candidate = CHECKPOINT / "candidate"
    if not candidate.exists():
        extract(candidate)
    if file_sha(JAR) != EXPECTED_JAR:
        raise RuntimeError("JAR_PREIMAGE_DRIFT")
    if file_sha(FRONTEND / "index.html") != EXPECTED_FRONTEND:
        raise RuntimeError("FRONTEND_PREIMAGE_DRIFT")
    if file_sha(candidate / "frontend/index.html") != EXPECTED_CANDIDATE_FRONTEND:
        raise RuntimeError("FRONTEND_ARTIFACT_MISMATCH")

    candidate_jar = CHECKPOINT / "candidate-application.jar"
    class_count = patched_jar(candidate, candidate_jar)
    staged_frontend = CHECKPOINT / "staged-frontend"
    if not staged_frontend.exists():
        shutil.copytree(candidate / "frontend", staged_frontend)
    base_unit, configured_unit = generated_backend_unit(CHECKPOINT)
    print(
        "PREFLIGHT_OK",
        json.dumps({"release": RELEASE, "classes": class_count, "frontend": EXPECTED_CANDIDATE_FRONTEND}),
        flush=True,
    )
    if sys.argv[1] == "--check":
        return

    run(
        "dnf",
        "-y",
        "install",
        "python3.11",
        "gdal",
        "gdal-python-tools",
        "python3-gdal",
    )
    install_worker(candidate)
    shutil.copy2(JAR, CHECKPOINT / "before-application.jar")
    shutil.copytree(FRONTEND, CHECKPOINT / "before-frontend")
    shutil.copy2(Path("/etc/systemd/system") / BACKEND_SERVICE, CHECKPOINT / "before-backend.service")
    backend_changed = False
    frontend_changed = False
    try:
        run("systemctl", "stop", BACKEND_SERVICE)
        os.replace(candidate_jar, JAR)
        shutil.copy2(configured_unit, Path("/etc/systemd/system") / BACKEND_SERVICE)
        os.chmod(Path("/etc/systemd/system") / BACKEND_SERVICE, 0o600)
        run("systemctl", "daemon-reload")
        run("systemctl", "start", BACKEND_SERVICE)
        backend_changed = True
        health()

        os.rename(FRONTEND, CHECKPOINT / "replaced-frontend")
        os.rename(staged_frontend, FRONTEND)
        frontend_changed = True
        run("podman", "restart", FRONTEND_CONTAINER, stdout=subprocess.DEVNULL)
        health()

        result = {
            "release": RELEASE,
            "backendCommit": "225966dbabab471972b2628a189ed9fc1ee87948",
            "frontendCommit": "d996cd9afba3ff3e688a06efc460f3f12dd6a274",
            "classes": class_count,
            "jar": file_sha(JAR),
            "frontend": file_sha(FRONTEND / "index.html"),
            "imageryRoot": str(IMAGERY_ROOT),
        }
        released.write_text(json.dumps(result, indent=2) + "\n")
        print("WEEKLY_IMAGERY_DEPLOY_OK", json.dumps(result), flush=True)
    except BaseException:
        if frontend_changed:
            os.rename(FRONTEND, CHECKPOINT / "failed-frontend")
            shutil.copytree(CHECKPOINT / "before-frontend", FRONTEND)
            subprocess.call(["podman", "restart", FRONTEND_CONTAINER])
        if backend_changed:
            subprocess.call(["systemctl", "stop", BACKEND_SERVICE])
        shutil.copy2(CHECKPOINT / "before-application.jar", JAR)
        restore_container(base_unit)
        print("WEEKLY_IMAGERY_DEPLOY_ROLLED_BACK", flush=True)
        raise


if __name__ == "__main__":
    main()
